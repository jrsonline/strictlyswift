//: Playground - noun: a place where people can play

///////////////////////  PART 1   ///////////////////////
// First let's set up a couple of different collections
let linkedList = LinkedList.start(2).addToStart(3).addToEnd(4)
let regularArray = [3,2,4]

// Next, define some functions
let isOdd = {$0 % 2 == 1}
let stringIt = { $0 ? "yes" : "no" }

// We have made LinkedList and Array conform to Functor(Tag) so we can now fmap them
// First we need to lift the LinkedList and Array to Construct<ArrayTag,Int> and Construct<LinkedListTag,Int>
// The ^ operator does that magic
// Once we've done our lifted stuff, we .lower (equivalently use the operator ¬) back to the original type

let oddsA1 =   linkedList^.fmap(isOdd).fmap(stringIt).lower
let oddsA2 = regularArray^.fmap(isOdd).fmap(stringIt)¬


///////////////////////  PART 2   ///////////////////////
// We can also do some higher-order function stuff with fmap
// I'm going to define a couple of typealiases though to make this easier to read
typealias 𝜑<C : HKTTag,T> = Construct<C,T>
typealias Functor𝜏 = FunctorTag

// Then we let's define checkOdd and stringize as below
// Note the typealiases de-emphasize the lifted types and emphasize what's happening

func checkOdd< F :Functor𝜏 >(_ c: 𝜑<F,Int>) -> 𝜑<F,Bool> { return c.fmap(isOdd) }
func stringize< F :Functor𝜏 >(_ c: 𝜑<F,Bool>) -> 𝜑<F,String> { return c.fmap(stringIt) }

// Next some continuation-passing-style operators  (see Pointfree) :

precedencegroup LeftApply {
    associativity: left
    higherThan: LogicalConjunctionPrecedence
}

infix operator |> : LeftApply
func |><F, A,B>(x: 𝜑<F,A>, f:@escaping (𝜑<F,A>) -> 𝜑<F,B>) -> 𝜑<F,B> {
    return f(x)
}
precedencegroup RightCompose {
    associativity: left
    higherThan: LeftApply
}
infix operator >>> : RightCompose
func >>><T, A,B,C>(f:@escaping (𝜑<T,A>) -> 𝜑<T,B>, g:@escaping (𝜑<T,B>)->𝜑<T,C>) -> (𝜑<T,A>) -> 𝜑<T,C> {
    return { a in g(f(a)) }
}



// Lastly we can write this, which does the same as oddsA1 and oddsA2 but (*I* think) looks better
// it really highlights the functions which are being applied, and hides the "fmap" mechanics.
// The lift ^ and lower ¬  nicely de-emphasize Construct (without obscuring it entirely)

let oddsB1 =   linkedList^ |> checkOdd >>> stringize >>>¬ toLinkedList
let oddsB2 = regularArray^ |> checkOdd >>> stringize >>>¬ toArray


///////////////////////  EXPERIMENT!   ///////////////////////
// 1. Create a Tree<Int> and map the same functions over that. Write some more functions to map.
// 2. Which do you prefer, the "dot" style of oddsA1, or the continuation-passing-style ? What about 𝜑, 𝜏 ?
// 3. Create a function classify (𝜑<T,Int>) -> ((𝜑<T,Int>) -> 𝜑<T,String>) which combines checkOdd >>> stringize
// 4. Is it a good idea to create a version of |> which works directly on the lowered types Array, LinkedList , etc?
// 5. Implement a mapping between functors, eg from LinkedList<A> -> Array<A>.
// 6. The 'Optional' type (A?) is also a functor; and fmap does what you might expect (experiment!). Can we use fmap to implement a mapping over a linked list of optional integers LinkedList<Int?>  ? Which fmap is used - LinkedList's or Optional's ?
// Note that our familiar other Sequence functions like reduce, flatmap, filter etc are missing! We'll tackle them next time when we talk about Applicatives and Monads



